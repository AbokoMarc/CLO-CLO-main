/* ============================================================
   CLO-CLO | api.js
   Petit client HTTP pour parler au backend. Gère l'ajout
   automatique du jeton de session et la gestion d'erreurs.
   ============================================================ */
const CloCloAPI = {
  TOKEN_KEY: "cloclo_token",

  getToken() { return localStorage.getItem(this.TOKEN_KEY); },
  setToken(t) { localStorage.setItem(this.TOKEN_KEY, t); },
  clearToken() { localStorage.removeItem(this.TOKEN_KEY); },

  async request(method, path, body) {
    const headers = { "Content-Type": "application/json" };
    const token = this.getToken();
    if (token) headers["Authorization"] = `Bearer ${token}`;

    let res;
    try {
      res = await fetch(`${window.CLOCLO_API_BASE}${path}`, {
        method,
        headers,
        body: body !== undefined ? JSON.stringify(body) : undefined,
      });
    } catch (e) {
      throw new Error("Impossible de contacter le serveur. Vérifie ta connexion.");
    }

    let data = {};
    try { data = await res.json(); } catch { /* réponse vide */ }

    if (!res.ok) {
      const err = new Error(data.error || `Erreur ${res.status}`);
      err.status = res.status;
      throw err;
    }
    return data;
  },

  get(path)        { return this.request("GET", path); },
  post(path, body) { return this.request("POST", path, body); },
  put(path, body)  { return this.request("PUT", path, body); },
  del(path)        { return this.request("DELETE", path); },

  async logout(redirectTo = "connexion.html") {
    try { await this.post("/auth/logout"); } catch { /* on nettoie quand même */ }
    this.clearToken();
    window.location.href = redirectTo;
  },
};
