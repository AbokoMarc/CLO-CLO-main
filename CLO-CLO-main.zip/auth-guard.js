/* ============================================================
   CLO-CLO | auth-guard.js
   À inclure en <head>, AVANT le script propre à la page, sur
   toute page qui doit être protégée. Nécessite config.js et
   api.js chargés juste avant.

   Utilisation :
   <script src="config.js"></script>
   <script src="api.js"></script>
   <script src="auth-guard.js"
           data-role="directeur"
           data-login="connexion-directeur.html"></script>

   Avant : la protection reposait sur un simple indicateur
   "cloclo_role" dans localStorage, jamais vérifié par les pages
   elles-mêmes → n'importe qui pouvait ouvrir l'URL directement.
   Maintenant : la page reste masquée tant que le serveur n'a
   pas confirmé un jeton de session valide ET le bon rôle.
   ============================================================ */
(function () {
  const thisScript = document.currentScript;
  const requiredRole = thisScript.dataset.role;
  const loginPage = thisScript.dataset.login || "connexion.html";

  // Masque immédiatement la page tant que la vérification n'est pas faite,
  // pour éviter d'afficher brièvement du contenu protégé.
  const style = document.createElement("style");
  style.id = "cloclo-guard-style";
  style.textContent = "html{visibility:hidden!important;}";
  document.documentElement.appendChild(style);

  function reveal() {
    const s = document.getElementById("cloclo-guard-style");
    if (s) s.remove();
  }

  function redirectToLogin() {
    CloCloAPI.clearToken();
    const next = encodeURIComponent(window.location.pathname);
    window.location.replace(`${loginPage}?next=${next}`);
  }

  let resolveReady;
  // D'autres scripts de page (ex: app-data.js) peuvent faire
  // `await window.CLOCLO_AUTH_READY` pour être sûrs de n'utiliser
  // que des données d'utilisateur confirmées par le serveur.
  window.CLOCLO_AUTH_READY = new Promise(resolve => { resolveReady = resolve; });

  async function check() {
    if (!CloCloAPI.getToken()) return redirectToLogin();
    try {
      const data = await CloCloAPI.get("/auth/me");
      if (data.role !== requiredRole) return redirectToLogin();
      // Rend l'utilisateur courant disponible aux scripts de la page,
      // sans jamais faire confiance à une donnée locale non vérifiée.
      window.CLOCLO_CURRENT_USER = data.user;
      reveal();
      resolveReady(data.user);
    } catch (e) {
      redirectToLogin();
    }
  }

  check();
})();
