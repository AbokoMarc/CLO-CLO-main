# CLO-CLO — Corrections de sécurité + Backend

Ce document résume tout ce qui a été corrigé par rapport à la version originale,
et comment faire tourner le projet en local.

## 1. Ce qui a été corrigé

| Problème original | Correction |
|---|---|
| Identifiants (email/mdp admin, livreur, directeur) écrits en clair dans `connexion.js`, visibles via F12 | Supprimés du code. Le backend compare un hash (scrypt) du mot de passe, jamais le mot de passe en clair. |
| Aucune page admin/livreur ne vérifiait de session → accessibles en tapant juste l'URL | Ajout de `auth-guard.js` sur chaque page protégée : elle interroge le serveur (`/api/auth/me`) et redirige si le jeton est absent/invalide/mauvais rôle. Le contenu reste masqué (`visibility:hidden`) tant que ce n'est pas confirmé. |
| Un client qui se connectait recevait par erreur le rôle `"admin"` | Le système de rôle par variable locale a été entièrement supprimé ; le rôle vient désormais du jeton signé par le serveur. |
| Tout était calculable/modifiable côté client (points, total du panier, statut de commande) | Le total d'une commande est toujours recalculé côté serveur à partir du catalogue officiel (`backend/lib/catalog.js`) — un prix envoyé par le navigateur est ignoré. |
| `innerHTML` utilisé avec des données modifiables sans échappement (risque XSS stocké) | Ajout de `escapeHTML()` (`utils.js`), utilisé partout où une donnée utilisateur est insérée dans le DOM. |
| Pas de vraie API : tout dans `localStorage` | Ajout d'un backend complet (`/backend`) : inscription, connexion, profil, commandes, historique de points, espace livreur, espace admin. |
| *(bug découvert en cours de route)* `app-data.js` (les vraies données du compte) n'était inclus dans **aucune** page HTML — le profil affichait toujours les mêmes fausses données de démo | Le fichier est maintenant chargé sur `profil.html`/`suivie.html` et synchronisé avec le backend au chargement. |
| *(bug découvert en cours de route)* `profil.js` contenait deux scripts concurrents collés ensemble (ancienne version démo + nouvelle version), causant des doublons d'événements (double toast, double déduction de points) | Le fichier a été nettoyé pour ne garder qu'une seule implémentation, connectée au backend. |

## 2. Ce qui reste volontairement en dehors de cette passe

- **Tableau de bord admin (`admin.js`)** : les graphiques et listes de clients/livreurs/livraisons sont encore des données statiques de démonstration. Le backend expose déjà les routes nécessaires (`/api/admin/clients`, `/api/admin/livreurs`, `/api/admin/livraisons`, `/api/admin/historique`, `/api/admin/stats`) — il reste à faire consommer ces routes par `admin.js` pour remplacer le HTML statique par les vraies données. Dis-moi si tu veux que je fasse cette partie aussi.
- **Panier / checkout sur `menu.html`** : le panier y est actuellement purement visuel (pas de bouton « passer commande » relié à quoi que ce soit). Le backend est prêt (`POST /api/orders`) mais il faut construire ce flux d'achat.
- **Utilisation des récompenses** : la déduction de points se fait encore uniquement côté navigateur (pas d'endpoint `/api/rewards/:id/use`), donc elle ne persiste pas après rechargement. À faire si tu veux que ce soit réellement durable.

## 3. Faire tourner le projet en local

### Backend
Aucune installation nécessaire (aucune dépendance externe, seulement Node.js ≥ 18) :
```bash
cd backend
node server.js
```
Le serveur démarre sur `http://localhost:4000` et crée un fichier `backend/data.json`
(ta base de données) au premier lancement, avec 3 comptes de démo :
- Client : `marie.kambale@email.com` / `marie123`
- Livreur : `DRV-001` / `driver123`
- Directeur : `admin` / `admin123` ⚠️ à changer avant toute vraie mise en ligne

### Frontend
Sers les fichiers HTML/CSS/JS à la racine avec n'importe quel serveur statique, par exemple :
```bash
npx serve .
# ou
python3 -m http.server 5500
```
`config.js` détecte automatiquement `localhost` et pointe vers `http://localhost:4000/api`.

### Déploiement
- **Frontend** : reste sur Vercel comme aujourd'hui, aucun changement nécessaire.
- **Backend** : Vercel (serverless) ne convient **pas** tel quel car `data.json` doit persister sur disque entre les requêtes, ce que les fonctions serverless ne garantissent pas. Héberge plutôt le dossier `backend/` sur un service à processus persistant : Render, Railway, Fly.io, ou un petit VPS. Une fois déployé, mets à jour l'URL dans `config.js` (variable `CLOCLO_API_BASE`) et définis `JWT_SECRET` + `CORS_ORIGIN` dans les variables d'environnement de l'hébergeur (voir `backend/.env.example`).

## 4. Fichiers ajoutés

```
backend/
  server.js          → serveur HTTP + toutes les routes API
  lib/auth.js         → hachage mot de passe + jetons de session signés
  lib/store.js         → persistance JSON + comptes de démo
  lib/catalog.js        → catalogue produits "officiel" (prix serveur)
  package.json, .env.example, .gitignore

config.js     → URL de l'API (à adapter en prod)
api.js         → client HTTP réutilisé par toutes les pages
auth-guard.js    → protection réelle des pages admin/livreur/client
utils.js          → escapeHTML() anti-XSS
```
