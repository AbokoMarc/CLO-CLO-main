/* ============================================================
   CLO-CLO BACKEND | server.js
   Serveur HTTP « zéro dépendance » (module natif node:http).
   Lancement :  node server.js
   Variables d'env utiles (voir .env.example) :
     PORT          (défaut 4000)
     JWT_SECRET    (obligatoire en production)
     CORS_ORIGIN   (défaut *)
   ============================================================ */
import http from "node:http";
import crypto from "node:crypto";
import { loadDB, persist } from "./lib/store.js";
import {
  hashPassword, verifyPassword,
  signToken, verifyToken,
  checkRateLimit, resetRateLimit,
} from "./lib/auth.js";
import { PRODUCTS, priceFor } from "./lib/catalog.js";

const PORT = process.env.PORT || 4000;
const CORS_ORIGIN = process.env.CORS_ORIGIN || "*";

const db = loadDB();

/* ---------------------------------------------------------
   Aides HTTP
--------------------------------------------------------- */

function sendJSON(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
    "Access-Control-Allow-Origin": CORS_ORIGIN,
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    let size = 0;
    req.on("data", chunk => {
      size += chunk.length;
      if (size > 1_000_000) { // garde-fou anti flood 1MB
        reject(new Error("Corps de requête trop volumineux"));
        req.destroy();
        return;
      }
      data += chunk;
    });
    req.on("end", () => {
      if (!data) return resolve({});
      try { resolve(JSON.parse(data)); }
      catch { reject(new Error("JSON invalide")); }
    });
    req.on("error", reject);
  });
}

// Échappe le texte fourni par l'utilisateur avant de le stocker/renvoyer,
// en complément de l'échappement fait côté front à l'affichage (innerHTML).
function sanitize(str, max = 300) {
  if (typeof str !== "string") return "";
  return str.trim().slice(0, max);
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email || "");
}

/* ---------------------------------------------------------
   Authentification : extraction + vérification du jeton
--------------------------------------------------------- */

function getAuthUser(req) {
  const header = req.headers["authorization"] || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return null;
  if (db.revokedTokens.includes(token)) return null;
  const payload = verifyToken(token);
  if (!payload) return null;
  return { ...payload, _token: token };
}

function requireRole(...roles) {
  return (req, res) => {
    const user = getAuthUser(req);
    if (!user) {
      sendJSON(res, 401, { error: "Non authentifié. Merci de vous reconnecter." });
      return null;
    }
    if (!roles.includes(user.role)) {
      sendJSON(res, 403, { error: "Accès refusé pour ce rôle." });
      return null;
    }
    return user;
  };
}

/* ---------------------------------------------------------
   Routes
--------------------------------------------------------- */

const routes = [];
function route(method, pattern, handler) {
  routes.push({ method, pattern, handler });
}

function matchRoute(method, pathname) {
  for (const r of routes) {
    if (r.method !== method) continue;
    const parts = r.pattern.split("/").filter(Boolean);
    const urlParts = pathname.split("/").filter(Boolean);
    if (parts.length !== urlParts.length) continue;
    const params = {};
    let ok = true;
    for (let i = 0; i < parts.length; i++) {
      if (parts[i].startsWith(":")) params[parts[i].slice(1)] = decodeURIComponent(urlParts[i]);
      else if (parts[i] !== urlParts[i]) { ok = false; break; }
    }
    if (ok) return { handler: r.handler, params };
  }
  return null;
}

/* ----- Public ----- */

route("GET", "/api/products", (req, res) => {
  sendJSON(res, 200, { products: PRODUCTS });
});

/* ----- Auth ----- */

route("POST", "/api/auth/register", async (req, res, params, body) => {
  const nom = sanitize(body.nom, 80);
  const email = sanitize(body.email, 120).toLowerCase();
  const tel = sanitize(body.tel, 30);
  const mdp = body.mdp || "";

  if (!nom || !isValidEmail(email) || !tel || mdp.length < 6) {
    return sendJSON(res, 400, { error: "Champs invalides. Le mot de passe doit contenir au moins 6 caractères." });
  }
  if (db.clients.some(c => c.email === email)) {
    return sendJSON(res, 409, { error: "Un compte existe déjà avec cet email." });
  }

  const client = {
    id: "CLT-" + crypto.randomBytes(4).toString("hex").toUpperCase(),
    nom, email, tel,
    adresse: "",
    passwordHash: hashPassword(mdp),
    points: 0,
    commandes: 0,
    niveau: "Bronze",
    createdAt: new Date().toISOString(),
  };
  db.clients.push(client);
  persist();

  const token = signToken({ sub: client.id, role: "client" });
  sendJSON(res, 201, { token, user: publicClient(client) });
});

route("POST", "/api/auth/login", async (req, res, params, body) => {
  const role = body.role;
  const ip = req.socket.remoteAddress || "unknown";
  const rateKey = `${ip}:${role}:${body.identifiant || ""}`;

  const rate = checkRateLimit(rateKey);
  if (!rate.allowed) {
    return sendJSON(res, 429, { error: `Trop de tentatives. Réessaie dans ${rate.retryAfter}s.` });
  }

  let account = null, publicUser = null;

  if (role === "client") {
    const email = sanitize(body.identifiant, 120).toLowerCase();
    account = db.clients.find(c => c.email === email);
    if (account && verifyPassword(body.mdp || "", account.passwordHash)) publicUser = publicClient(account);
  } else if (role === "livreur") {
    const id = sanitize(body.identifiant, 40);
    account = db.livreurs.find(l => l.id === id);
    if (account && verifyPassword(body.mdp || "", account.passwordHash)) publicUser = publicLivreur(account);
  } else if (role === "directeur") {
    const user = sanitize(body.identifiant, 40);
    account = db.directeurs.find(d => d.user === user);
    if (account && verifyPassword(body.mdp || "", account.passwordHash)) publicUser = publicDirecteur(account);
  } else {
    return sendJSON(res, 400, { error: "Rôle invalide." });
  }

  if (!account || !publicUser) {
    return sendJSON(res, 401, { error: "Identifiants incorrects." });
  }

  resetRateLimit(rateKey);
  const token = signToken({ sub: account.id, role });
  sendJSON(res, 200, { token, user: publicUser });
});

route("POST", "/api/auth/logout", async (req, res) => {
  const user = getAuthUser(req);
  if (user) {
    db.revokedTokens.push(user._token);
    persist();
  }
  sendJSON(res, 200, { ok: true });
});

route("GET", "/api/auth/me", async (req, res) => {
  const user = getAuthUser(req);
  if (!user) return sendJSON(res, 401, { error: "Session invalide ou expirée." });

  if (user.role === "client") {
    const acc = db.clients.find(c => c.id === user.sub);
    if (!acc) return sendJSON(res, 404, { error: "Compte introuvable." });
    return sendJSON(res, 200, { role: "client", user: publicClient(acc) });
  }
  if (user.role === "livreur") {
    const acc = db.livreurs.find(l => l.id === user.sub);
    if (!acc) return sendJSON(res, 404, { error: "Compte introuvable." });
    return sendJSON(res, 200, { role: "livreur", user: publicLivreur(acc) });
  }
  if (user.role === "directeur") {
    const acc = db.directeurs.find(d => d.id === user.sub);
    if (!acc) return sendJSON(res, 404, { error: "Compte introuvable." });
    return sendJSON(res, 200, { role: "directeur", user: publicDirecteur(acc) });
  }
  sendJSON(res, 400, { error: "Rôle inconnu." });
});

/* ----- Espace client ----- */

route("GET", "/api/profile", (req, res) => {
  const user = requireRole("client")(req, res);
  if (!user) return;
  const acc = db.clients.find(c => c.id === user.sub);
  sendJSON(res, 200, { user: publicClient(acc) });
});

route("PUT", "/api/profile", async (req, res, params, body) => {
  const user = requireRole("client")(req, res);
  if (!user) return;
  const acc = db.clients.find(c => c.id === user.sub);
  if (body.nom !== undefined) acc.nom = sanitize(body.nom, 80);
  if (body.tel !== undefined) acc.tel = sanitize(body.tel, 30);
  if (body.adresse !== undefined) acc.adresse = sanitize(body.adresse, 200);
  persist();
  sendJSON(res, 200, { user: publicClient(acc) });
});

route("GET", "/api/orders", (req, res) => {
  const user = requireRole("client")(req, res);
  if (!user) return;
  const orders = db.orders.filter(o => o.clientId === user.sub);
  sendJSON(res, 200, { orders });
});

route("POST", "/api/orders", async (req, res, params, body) => {
  const user = requireRole("client")(req, res);
  if (!user) return;
  const acc = db.clients.find(c => c.id === user.sub);

  const items = Array.isArray(body.items) ? body.items : [];
  if (items.length === 0) return sendJSON(res, 400, { error: "Le panier est vide." });

  // Le total est TOUJOURS recalculé côté serveur à partir du catalogue
  // officiel : on ignore volontairement tout prix envoyé par le client.
  let total = 0;
  const articles = [];
  for (const it of items) {
    const price = priceFor(it.id);
    const qty = Math.max(1, Math.min(50, parseInt(it.qty, 10) || 1));
    if (price === null) return sendJSON(res, 400, { error: `Produit inconnu : ${it.id}` });
    total += price * qty;
    const p = PRODUCTS.find(p => p.id === it.id);
    articles.push(`${p.name} x${qty}`);
  }

  const order = {
    id: "CMD-" + new Date().getFullYear() + "-" + crypto.randomBytes(3).toString("hex").toUpperCase(),
    clientId: acc.id,
    date: new Date().toISOString(),
    articles,
    total,
    adresse: sanitize(body.adresse, 200) || acc.adresse,
    statut: "en_preparation",
    livreurId: null,
  };
  db.orders.unshift(order);

  const pts = Math.floor(total / 500) * 5;
  acc.points += pts;
  acc.commandes += 1;
  db.pointsHistory.unshift({
    clientId: acc.id,
    label: `Commande #${order.id}`,
    date: new Date().toISOString(),
    pts: pts,
    type: "gain",
  });
  persist();

  sendJSON(res, 201, { order, pointsEarned: pts });
});

route("GET", "/api/points-history", (req, res) => {
  const user = requireRole("client")(req, res);
  if (!user) return;
  const history = db.pointsHistory.filter(h => h.clientId === user.sub);
  sendJSON(res, 200, { history });
});

/* ----- Espace livreur ----- */

route("GET", "/api/livreur/livraisons", (req, res) => {
  const user = requireRole("livreur")(req, res);
  if (!user) return;
  const livraisons = db.orders.filter(o =>
    (o.livreurId === user.sub) || (o.livreurId === null && o.statut !== "livree")
  );
  sendJSON(res, 200, { livraisons });
});

route("PUT", "/api/livreur/livraisons/:id/statut", async (req, res, params, body) => {
  const user = requireRole("livreur")(req, res);
  if (!user) return;
  const order = db.orders.find(o => o.id === params.id);
  if (!order) return sendJSON(res, 404, { error: "Commande introuvable." });

  const allowed = ["en_preparation", "en_livraison", "livree"];
  if (!allowed.includes(body.statut)) return sendJSON(res, 400, { error: "Statut invalide." });

  order.livreurId = user.sub;
  order.statut = body.statut;
  persist();
  sendJSON(res, 200, { order });
});

route("GET", "/api/livreur/historique", (req, res) => {
  const user = requireRole("livreur")(req, res);
  if (!user) return;
  const historique = db.orders.filter(o => o.livreurId === user.sub && o.statut === "livree");
  sendJSON(res, 200, { historique });
});

/* ----- Espace directeur / admin ----- */

route("GET", "/api/admin/clients", (req, res) => {
  const user = requireRole("directeur")(req, res);
  if (!user) return;
  sendJSON(res, 200, { clients: db.clients.map(publicClient) });
});

route("GET", "/api/admin/livreurs", (req, res) => {
  const user = requireRole("directeur")(req, res);
  if (!user) return;
  sendJSON(res, 200, { livreurs: db.livreurs.map(publicLivreur) });
});

route("POST", "/api/admin/livreurs", async (req, res, params, body) => {
  const user = requireRole("directeur")(req, res);
  if (!user) return;
  const id = sanitize(body.id, 30) || ("DRV-" + crypto.randomBytes(3).toString("hex").toUpperCase());
  const nom = sanitize(body.nom, 80);
  const tel = sanitize(body.tel, 30);
  const mdp = body.mdp || "";
  if (!nom || mdp.length < 6) return sendJSON(res, 400, { error: "Champs invalides." });
  if (db.livreurs.some(l => l.id === id)) return sendJSON(res, 409, { error: "Cet identifiant existe déjà." });

  const livreur = { id, nom, tel, passwordHash: hashPassword(mdp), statut: "disponible", createdAt: new Date().toISOString() };
  db.livreurs.push(livreur);
  persist();
  sendJSON(res, 201, { livreur: publicLivreur(livreur) });
});

route("GET", "/api/admin/livraisons", (req, res) => {
  const user = requireRole("directeur")(req, res);
  if (!user) return;
  sendJSON(res, 200, { orders: db.orders });
});

route("GET", "/api/admin/historique", (req, res) => {
  const user = requireRole("directeur")(req, res);
  if (!user) return;
  sendJSON(res, 200, { orders: db.orders.filter(o => o.statut === "livree") });
});

route("GET", "/api/admin/stats", (req, res) => {
  const user = requireRole("directeur")(req, res);
  if (!user) return;
  sendJSON(res, 200, {
    totalClients: db.clients.length,
    totalLivreurs: db.livreurs.length,
    totalCommandes: db.orders.length,
    chiffreAffaires: db.orders.reduce((s, o) => s + o.total, 0),
  });
});

/* ---------------------------------------------------------
   Vues publiques (jamais renvoyer passwordHash au client)
--------------------------------------------------------- */

function publicClient(c) {
  return { id: c.id, nom: c.nom, email: c.email, tel: c.tel, adresse: c.adresse, points: c.points, commandes: c.commandes, niveau: c.niveau };
}
function publicLivreur(l) {
  return { id: l.id, nom: l.nom, tel: l.tel, statut: l.statut };
}
function publicDirecteur(d) {
  return { id: d.id, user: d.user };
}

/* ---------------------------------------------------------
   Serveur
--------------------------------------------------------- */

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);

  if (req.method === "OPTIONS") {
    return sendJSON(res, 204, {});
  }

  const matched = matchRoute(req.method, url.pathname);
  if (!matched) {
    return sendJSON(res, 404, { error: "Route introuvable." });
  }

  try {
    const body = ["POST", "PUT", "DELETE"].includes(req.method) ? await readBody(req) : {};
    await matched.handler(req, res, matched.params, body);
  } catch (e) {
    console.error(e);
    sendJSON(res, 400, { error: e.message || "Requête invalide." });
  }
});

server.listen(PORT, () => {
  console.log(`✅ CLO-CLO backend démarré sur http://localhost:${PORT}`);
  console.log(`   Comptes de démo : client marie.kambale@email.com / marie123`);
  console.log(`                     livreur DRV-001 / driver123`);
  console.log(`                     directeur admin / admin123  (⚠️ à changer en prod)`);
});
