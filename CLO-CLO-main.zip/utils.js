/* ============================================================
   CLO-CLO | utils.js
   Échappe une chaîne avant de l'insérer via innerHTML, pour
   éviter qu'un nom, une adresse ou un commentaire contenant
   du HTML/JS ne soit exécuté dans la page (XSS stocké).
   Toujours utiliser escapeHTML() autour de toute donnée qui
   provient d'un utilisateur (même indirectement, via l'API).
   ============================================================ */
function escapeHTML(str) {
  if (str === null || str === undefined) return "";
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}
