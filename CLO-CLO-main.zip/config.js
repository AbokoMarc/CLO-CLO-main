/* ============================================================
   CLO-CLO | config.js
   Un seul endroit à modifier pour pointer vers le backend.
   - En local : laisse "http://localhost:4000/api"
   - En production : remplace par l'URL de ton backend déployé
     (ex : "https://clo-clo-api.onrender.com/api")
   ============================================================ */
window.CLOCLO_API_BASE =
  (window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1")
    ? "http://localhost:4000/api"
    : "https://clo-clo-api.onrender.com/api"; // ⚠️ à remplacer par ton URL de backend déployé
