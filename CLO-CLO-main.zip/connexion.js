/* ============================================================
   CLO-CLO | connexion.js  (partagé : client + livreur + directeur)
   ------------------------------------------------------------
   AVANT : les identifiants et mots de passe étaient écrits en
   clair dans ce fichier JS (visibles par n'importe qui via F12),
   et la connexion se faisait par simple comparaison locale.
   MAINTENANT : les identifiants ne sont jamais présents dans le
   code. La vérification se fait côté serveur, qui compare le mot
   de passe à un hash (scrypt) et renvoie un jeton de session signé.
   ============================================================ */

/* ── Détection de la page courante ── */
const page = window.location.pathname;
const isLivreur   = page.includes("connexion-livreur");
const isDirecteur = page.includes("connexion-directeur");
const isClient    = !isLivreur && !isDirecteur;

const ROLE = isLivreur ? "livreur" : isDirecteur ? "directeur" : "client";
const REDIRECT = isLivreur ? "livreur-dashboard.html" : isDirecteur ? "admin-dashboard.html" : "profil.html";

/* ── Afficher / masquer mot de passe ── */
document.querySelectorAll(".toggle-pwd").forEach(btn => {
  btn.addEventListener("click", () => {
    const input = document.getElementById(btn.dataset.target);
    if (input) input.type = input.type === "password" ? "text" : "password";
  });
});

/* ── Utilitaires erreurs ── */
function setError(id, msg) {
  const el = document.getElementById(id);
  if (el) el.textContent = msg;
}
function clearErrors() {
  document.querySelectorAll(".error-msg").forEach(el => el.textContent = "");
  document.querySelectorAll(".input-wrap").forEach(el => el.classList.remove("error"));
}
function markError(inputId, errId, msg) {
  setError(errId, msg);
  document.getElementById(inputId)?.closest(".input-wrap")?.classList.add("error");
}

/* ── Lecture des champs selon le rôle ── */
function readIdentifiant() {
  if (isLivreur)   return document.getElementById("input-id")?.value.trim();
  if (isDirecteur) return document.getElementById("input-user")?.value.trim();
  return document.getElementById("input-email")?.value.trim();
}

function identifiantField() {
  if (isLivreur)   return { inputId: "input-id",   errId: "err-id"   };
  if (isDirecteur) return { inputId: "input-user", errId: "err-user" };
  return { inputId: "input-email", errId: "err-email" };
}

/* ── Validation & connexion (appelle le backend) ── */
async function login() {
  clearErrors();
  const identifiant = readIdentifiant();
  const mdp = document.getElementById("input-mdp")?.value;
  const { inputId, errId } = identifiantField();
  let ok = true;

  if (!identifiant) {
    markError(inputId, errId, isClient ? "Email invalide." : "Identifiant requis.");
    ok = false;
  }
  if (isClient && identifiant && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(identifiant)) {
    markError(inputId, errId, "Email invalide.");
    ok = false;
  }
  if (!mdp) {
    markError("input-mdp", "err-mdp", "Mot de passe requis.");
    ok = false;
  }
  if (!ok) return;

  const btn = document.getElementById("btn-login");
  const originalText = btn ? btn.textContent : "";
  if (btn) { btn.disabled = true; btn.textContent = "Connexion..."; }

  try {
    const data = await CloCloAPI.post("/auth/login", { role: ROLE, identifiant, mdp });
    CloCloAPI.setToken(data.token);
    success(REDIRECT);
  } catch (e) {
    if (btn) { btn.disabled = false; btn.textContent = originalText; }
    if (e.status === 429) {
      markError("input-mdp", "err-mdp", e.message);
    } else {
      markError("input-mdp", "err-mdp", "Identifiants incorrects.");
    }
  }
}

/* ── Succès : animation + redirection ── */
function success(redirect) {
  const btn = document.getElementById("btn-login");
  if (btn) {
    btn.textContent = "✓ Connexion réussie !";
    btn.style.background = "#16a34a";
    btn.disabled = true;
  }
  showToast("✅ Connexion réussie !");

  // Respecte un éventuel paramètre ?next=... déposé par auth-guard.js
  const params = new URLSearchParams(window.location.search);
  const next = params.get("next");
  const target = next ? decodeURIComponent(next) : redirect;

  setTimeout(() => window.location.href = target, 1400);
}

/* ── Toast ── */
function showToast(msg, color = "green") {
  const existing = document.querySelector(".toast");
  if (existing) existing.remove();
  const t = document.createElement("div");
  t.textContent = msg;
  Object.assign(t.style, {
    position: "fixed", bottom: "30px", right: "30px",
    background: color === "red" ? "#ef4444" : "#22c55e",
    color: "white", padding: "14px 24px", borderRadius: "12px",
    fontFamily: "'Nunito', sans-serif", fontWeight: "700", fontSize: "0.95rem",
    boxShadow: "0 6px 24px rgba(0,0,0,0.2)", zIndex: "9999",
    opacity: "1", transition: "opacity 0.3s",
  });
  document.body.appendChild(t);
  setTimeout(() => { t.style.opacity = "0"; setTimeout(() => t.remove(), 300); }, 2500);
}

/* ── Branchement du bouton ── */
document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("btn-login");
  if (!btn) return;

  btn.addEventListener("click", login);

  document.addEventListener("keydown", e => {
    if (e.key === "Enter") btn.click();
  });
});
